 import sys

def get_acc(filename):

    with open(filename, "r") as f:

        acc = f.read()

    print("mIou:", acc)


def get_perf(filename):

    with open(filename, "r") as f:

        perf = f.read()

    print("Perf:", perf)

 if __name__ == "__main__":

     filename = sys.argv[1]

     if filename.endswith(".log"):
         get_acc(filename)

     elif filename.endswith(".txt"):
        get_perf(filename)
