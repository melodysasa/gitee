  #!/bin/bash

DATASET_PATH=/home/sasa/dataset/cityscapes/

echo "====数据预处�?==="
rm -rf ./pre_dataset_bin
python3.7 pre_dataset.py $DATASET_PATH ./pre_dataset_bin
if [ $? != 0 ]; then
    echo "fail!"
    exit -1
fi
echo "====数据预处理完�?==="


echo "====生成数据info文件===="
rm -rf ./icnet_pre_bin_1024_2048.info
python3.7 get_info.py bin ./pre_dataset_bin ./icnet_pre_bin_1024_2048.info 1024 2048
if [ $? != 0 ]; then
    echo "fail!"
    exit -1
fi
echo "====生成数据info文件完成===="


echo "====bs1 benchmark推理===="
source env.sh
rm -rf result/dumpOutput_device0
./benchmark.x86_64 -model_type=vision -device_id=0 -batch_size=1 -om_path=./ICNet_bs1.om -input_text_path=./icnet_pre_bin_1024_2048.info -input_width=1024 -input_height=2048 -output_binary=True -useDvpp=False
if [ $? != 0 ]; then
    echo "fail!"
    exit -1
fi
echo "====bs1 benchmark推理完成===="


echo "====bs1 精度后处�?==="
python3.7 -u evaluate.py $DATASET_PATH ./result/dumpOutput_device0 ./prefix >icnet_bs1.log
if [ $? != 0 ]; then
    echo "fail!"
    exit -1
fi
echo "====bs1 精度后处理完�?==="


echo "====bs16 benchmark推理===="
source env.sh
rm -rf result/dumpOutput_device1
./benchmark.x86_64 -model_type=vision -device_id=1 -batch_size=1 -om_path=./ICNet_bs16.om -input_text_path=./icnet_pre_bin_1024_2048.info -input_width=1024 -input_height=2048 -output_binary=True -useDvpp=False
if [ $? != 0 ]; then
    echo "fail!"
    exit -1
fi
echo "====bs16 benchmark推理完成===="


echo "====bs16 精度后处�?==="
python3.7 -u evaluate.py $DATASET_PATH ./result/dumpOutput_device1 ./prefix >icnet_bs16.log
if [ $? != 0 ]; then
    echo "fail!"
    exit -1
fi
echo "====bs16 精度后处理完�?==="


echo "====accuracy data===="
echo "pth mIoU:69%"
python3.7 test/parse.py icnet_bs16.log
if [ $? != 0 ]; then
    echo "fail!"
    exit -1
fi
python3.7 test/parse.py icnet_bs16.log
if [ $? != 0 ]; then
    echo "fail!"
    exit -1
fi


echo "====performance data===="
echo "t4 bs1  fps:763.044"
echo "t4 bs16 fps:1234.940"
python3.7 test/parse.py result/perf_vision_batchsize_1_device_0.txt
if [ $? != 0 ]; then
    echo "fail!"
    exit -1
fi
python3.7 test/parse.py result/perf_vision_batchsize_16_device_1.txt
if [ $? != 0 ]; then
    echo "fail!"
    exit -1
fi
echo "success"