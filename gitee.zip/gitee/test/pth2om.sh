#!/bin/bash

rm -rf ICNet.onnx
python3.7 ICNet_pth2onnx.py icnet_resnet50_197_0.710_best_model.pth ICNet.onnx

source env.sh

rm -rf ICNet_bs1.om ICNet_bs4.om ICNet_bs8.om ICNet_bs16.om

atc --framework=5 --model=./ICNet.onnx --output=ICNet_bs1 --out_nodes="Resize_405:0" --input_format=NCHW --input_shape="actual_input_1: 1,3,1024,2048" --log=debug --soc_version=Ascend310
atc --framework=5 --model=./ICNet.onnx --output=ICNet_bs4 --out_nodes="Resize_405:0" --input_format=NCHW --input_shape="actual_input_1: 4,3,1024,2048" --log=debug --soc_version=Ascend310
atc --framework=5 --model=./ICNet.onnx --output=ICNet_bs8 --out_nodes="Resize_405:0" --input_format=NCHW --input_shape="actual_input_1: 8,3,1024,2048" --log=debug --soc_version=Ascend310
atc --framework=5 --model=./ICNet.onnx --output=ICNet_bs16 --out_nodes="Resize_405:0" --input_format=NCHW --input_shape="actual_input_1: 16,3,1024,2048" --log=debug --soc_version=Ascend310

if [ -f "ICNet_bs1.om" ] && [ -f "ICNet_bs4.om" ] && [ -f "ICNet_bs8.om" ] && [ -f "ICNet_bs16.om" ]; then
    echo "success"
else
    echo "fail!"
fi